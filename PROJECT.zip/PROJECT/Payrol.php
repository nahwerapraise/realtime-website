<html>
    <head>
    <style>
body{
    background-color:pink;
    font: lem/1.5 sans-serif;
}
h1{
   font-size: 40px;
   text-align: center;
   color: blue;
    
}
#det{
   font-size: 30px;
   text-align: center;
   color: green;
    
}

.ig{
    margin-left:250px;
    border-radius:50%;
}
.im{
    margin-left:330px;
    border-radius:50%;
}


form{
   font-weight:bolder;
   color: green;
    width: 500px;
    margin: 10px auto;
    
}

input{
   
    font-size: inherit;
    padding: 10px;
}

input[type="submit"]{
    margin-left:100px;
    height: 45px;
    border: none;
    background: rgb(180, 70, 165);
    color: white;
    width:290px;
    border-radius:15px;

}

input[type="number"]{
    
    border: 3px solid green;
    display: block;
    width: 500px;
    margin-bottom: 20px;
    height:45px;

   }




input[type="text"]{
    border: 3px solid green;
    display: block;
    width: 500px;
    margin-bottom: 20px;
    height:45px;

   }
   #clear{
    margin-left:100px; 
    height: 45px;
    border: none;
    background:red;
    color:#fff ;
    width:290px;
    border-radius:15px;
   
   }
    
#dish-selection{
    border: 3px solid green;
    display: block;
    width: 500px;
    margin-bottom: 20px;
    height:45px;  
}
    



</style>
    </head>

    <body >
   

   <h1>REAL TIME KITCHEN WARE PAYROLL SYSTEM</h1>
  



<h3 id="det">EMPLOYEE'S DETAILS</h3>
<form action="Result.php" method="POST" class="form">


  <labele class="label"></label>
  <label for="name"><h3>NAME:</h3></label>
  <input type="text" name="names" class="in" placeholder="Enter your name">
  <br>
  
  
  
  <br>
  <select  id="dish-selection" name="position"  required class="in">
              <option value="" selected disabled>SELECT YOUR POSITION IN THE COMPANY</option>
              <option value="Technical_expert" name="position">Technical_expert</option>
              <option value="manager" name="position">Manager</option>
              
            </select>  
            <br> <br>
            
  

<label for="basicpay"><h3>BASIC PAY:</h3></label>
  <input type="number" name="basicpay" class="in" placeholder="Enter your basic pay"> 
   <br>

  <label for="time served"><h3>TIME SERVED:</h3></label>
  <input type="number" name="timeserved" class="in" placeholder="For how long have you served?">  
   <br>
  
  <label for="working hours"><h3>WORKED HOURS:</h3></label>
  <input type="number" name="extrahours" class="in" placeholder="Enter extra hours you worked">
  <br>

  <br>
  <input  type="reset" value="Reset" placeholder="" id="clear"> 
  <br> <br>
   <input  type="submit" name="submit" value= "View payments" placeholder="" >
   <br> <br>

 </form>

 
 







</body>
</html>