<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>praise</title>
    <link rel="stylesheet" href="contact.css">
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css2?
    family=poppins:wght@100;200;300;400;600;700&display=swap"
    rel="stylesheet">

     <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 


<body>
    
    <section class="header">
        <nav>
   <a href="praise.html"> <img src="dishes.jpg"></a>
 
    
    <div class="nav-links" id="navLinks">
        <i class="fa fa-times" onclick="hideMenu()"></i>
  
    <ul>
        <li><a href="Home.php"> HOME</a></li>
        <li><a href="About.php"> ABOUT</a></li>
        <li><a href="offers.php"> OFFERS</a></li>
        <li><a href="staff.php"> STAFF</a></li>
        <li><a href="contact.php"> CONTACT</a></li>
    </ul>
    </div>
    <i class="fa fa-bars" onclick="showMenu()"></i>

    
    </nav>
    
    <div class="text-box">
    
        <h1>CONTACT US</h1>
    
        <p></p>
        <a href="mailto:nahwerapraise37@gmail.com "contact.php" class="hero-btn">Visit Us To Know More</a>
       
    </div>
    
    </section>



<section class="cta">

<h1>Our Global Location</h1>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.8350860649152!2d29.990439865575823!3d-1.2720333413472762!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x19dc0d990c000001%3A0x94a250234c8f3b2e!2sMwanjari!5e0!3m2!1sen!2sug!4v1650983944525!5m2!1sen!2sug" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


</section>


<section class="campus">
    <h1>Contact Our Branches</h1>
    <p>We have different braches across the country.</p> 

    <div class="row">

<div class="campus-col">
<img src="dishes.jpg">
<div class="layer">
    <h3> KABALE BRANCH</h3>
</div>
</div>





<div class="campus-col">
    <img src="s4.jpg">
    <div class="layer">
        <h3> NTUNGAMO BRANCH</h3>
    </div>
    </div>


<div class="campus-col">
<img src="flying pans.jpg">
<div class="layer">
    <h3> MBARARA BRANCH</h3>
</div>
</div>

</div>
</section>





<h1 class="wrdz">INQUIRY FORM</h1>
<form action="">
    
    <label for="">Name:</label>
    <br>
    <input type="text">
    <br> <br>

    <label for="">Contact:</label> <br>
    <input type="text">

    <br> <br>
    <label for="">Email:</label> <br>
    <input type="email">

    <br> <br>

    <label for="">Message:</label> <br>
    <input type="text">
    <br> <br>
    <input type="submit" value="Send message">
    <br>
</form>


<section class="footer">
<h4>About Us</h4>
<p>We are the best suppliers not only in Kabale but through out the entire globe <br> Your choice to order with us is our pride</p>

<div class="inner"> 
    <ul class="icons">
    <i><a href="https://facebook.com/Praise Nahwera" class="icon fa fa-facebook"><span class="label"> facebook</span></a></i>
    <i><a href="https://whatsapp.com/0782391493" class=" icon fa fa-whatsapp"><span class="label"> whatsapp</span></a></i>
    <i><a href="mailto:nahwerapraise37@gmail.com" class="icon fa fa-envelope"><span class="label"> Email</span></a></i>
    
 <p class="copyright">&copy; Untitled. Design: <a href "https://templated.co">TEMPLATED</a>.images:<a href="https://a.jpg"></a>  
</ul>
</div>

</section>
    
    

    <script>
    var navLinks = document.getElementById("navLinks");
    
    function showMenu(){
        navLinks.style.right = "0";
    } 
    function hideMenu() {
        navLinks.style.right = "-200px";
    } 
    </script>
    
    


    

</body>
</html>