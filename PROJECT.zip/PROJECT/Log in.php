




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="BookK.css">
    <title>Document</title>
</head>
<body>
    <form action="Book-result" method="POST">

<h1>CUSTOMER'S BOOKING DETAILS</h1>

<label for="branch">BUSINESS BRANCH: </label> <br>
<input type="text" name="branch" >  <br> <br>


<label for="title">TITLE:</label><br>
<input type="text" name="title"> <br> <br>


<label for="name">FULL NAME:</label><br>
<input type="text" name="fullname"> 

<br> <br> 


<label for="phone">PHONE:</label><br>
<input type="text" name="phone"> <br> <br>

<label for="saucepans">NUMBER OF SAUCEPANS: </label><br>
<input type="number" name="saucepans"> <br> <br>

<label for="plates">NUMBER OF PLATES:</label><br>
<input type="number" name="plates">

<br> <br> 

<label for="cups"> NUMBER OF CUPS: </label><br>
<input type="number" name="cups"> <br> <br>

<label for="date">DATE: </label><br>
<input type="date" name="date">  <br> <br>

<label for="email">EMAIL: </label><br>
<input type="email" name="email">

<br> <br>  <br>

<input type="submit" name="submit" value="Submit Your Details">







    </form>
</body>
</html>