<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praise</title>
    <link rel="stylesheet" href="About.css">
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css2?
    family=poppins:wght@100;200;300;400;600;700&display=swap"
    rel="stylesheet">

     <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 

  
<body>
    
    <section class="header">
        <nav>
   <a href="praise.html"> <img src="dishes.jpg"></a>
    
    <div class="nav-links" id="navLinks">
        <i class="fa fa-times" onclick="hideMenu()"></i>
   
    <ul>
        <li><a href="Home.php"> HOME</a></li>
        <li><a href="About.php"> ABOUT</a></li>
        <li><a href="offers.php"> OFFERS</a></li>
      <li><a href="staff.php"> STAFF</a></li>
        <li><a href="contact.php"> CONTACT</a></li>
    </ul>
    </div>
    <i class="fa fa-bars" onclick="showMenu()"></i>
  
    
    </nav>
    
    <div class="text-box">
    
        <h1>ABOUT US</h1>
    
        <p>Real Time Kitchen ware endeavors to provide discerning kitchen materials to customers by offering quality services  and <br> products  in Kabale. </p>
   
    
    </div>
    
    </section>


<section class="course"> 
<h1>Our business Statements</h1>
<p>These are some of the statements that are guiding the operarion of our Business </p>

<div class="row">
    <div class="course-col">
        <h3>Vision</h3>
        <p>The vision of our business is to provide outstanding kitchen materials and services to our customers. Our business focuses on kitchen materials and , as well as dining materials . We emphasise high quality standards in our business.</p>
    </div>
    <div class="course-col">
        <h3>Goal</h3>
        <p>The goal of our business is to increase our products or service's market share . Our business focuses on kitchen materials and, as well as dining materials.</p>   
    </div>
    <div class="course-col">
        <h3>Mission</h3>
        <p>The mission of our business is to be the Earth's most customer_centric business ,<br> where customers can find and discover anything they might want to buy online ,and endeavors to offer its customers the lowest possible prices.</p>
    </div>
</div>
</section>

<section class="facilities">
    <h1> Governing Directors</h1>
    <p>We have many projects that are meant to support the smooth running of our business.</p>

    <div class="row">
        
    
      

        <div class="facilities-col">
            <img src="p.jpg">
            <h3>NAHWERA PRAISE</h3>
            <p>We are so glad for her great support as one of the business Directors.</p>
        </div>

        <div class="facilities-col">
            <img src="derah.jpg">
            <h3>NATUMANYA ADERAH</h3>
            <p>We are so glad for her great support as one of the business Directors.</p>
        </div>

        <div class="facilities-col">
            <img src="a.jpg">
            <h3>OWOYESIGA ASHRAF</h3>
            <p>We are so glad for his great support as one of the business Director.</p>
        </div>


    </div>
</section>


<section class="facilities">
    <h1> Our Branch Staff</h1>
    <p>We have a well qualified and disciplined staff in all our branches across the country.</p>

    <div class="row">
        
        

        <div class="facilities-col">
            <img src="gr.jpg">
            <h3>Staff KABALE Branch</h3>
            <p>We are so glad for the great support for the business. </p>
        </div>

        <div class="facilities-col">
            <img src="photo.jpg">
            <h3>Staff NTUNGAMO Branch </h3>
            <p>We are so glad for the great support for the business.</p>
        </div>


        <div class="facilities-col">
            <img src="index.jpg">
            <h3>Staff MBARARA Branch</h3>
            <p>We are so glad for the great support for the business.</p>
        </div>
       
    </div>
</section>



<section class="footer">
<h4>About Us</h4>
<p>Real Time Kitchen Ware  endeavors to provide discerning kitchen materials to customers by offering quality services  and <br> products and in Africa and beyond.</p>

<div>
    <ul class="icons">
<i><a href="https://facebook.com/praise Nahwera" class="icon fa fa-facebook"><span class="label"> facebook</span></a></i>
<i><a href="https://whatsapp.com/0782391493" class=" icon fa fa-whatsapp"><span class="label"> whatsapp</span></a></i>
<i><a href="mailto:nahwerapraise37@gmail.com" class="icon fa fa-envelope"><span class="label"> Email</span></a></i>
 

</ul>
<p class="copyright">&copy; Untitled. Design: <a href "https://templated.co">TEMPLATED</a>.images:<a href="https://a.jpg"></a>    

</div>

</section>
    
    <script>
    var navLinks = document.getElementById("navLinks");
    
    function showMenu(){
        navLinks.style.right = "0";
    } 
    function hideMenu() {
        navLinks.style.right = "-200px";
    } 
    </script>
    


    
</body>
</html>