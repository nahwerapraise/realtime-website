<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>praise</title>
    <link rel="stylesheet" href="staff.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css2?
    family=poppins:wght@100;200;300;400;600;700&display=swap"
    rel="stylesheet">

     <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 

<body>
    
    <section class="header">
        <nav>
   <a href="praise.html"> <img src="dishes"></a>
 
    <div class="nav-links" id="navLinks">
        <i class="fa fa-times" onclick="hideMenu()"></i>
    
    <ul>
        <li><a href="Home.php"> HOME</a></li>
        <li><a href="About.php"> ABOUT</a></li>
        <li><a href="offers.php"> OFFERS</a></li>
      <li><a href="staff.php"> STAFF</a></li>
        <li><a href="contact.php"> CONTACT</a></li>
    </ul>
    </div>
    <i class="fa fa-bars" onclick="showMenu()"></i>

    </nav>
    
    <div class="text-box">
    
        <h1>OUR FRIENDLY STAFF</h1>
    
        <p>We have a well qualified and disciplined staff in all our branches across the country.</p>

    </div>
    
    </section>

<section class="facilities">
    <h1> Governing Directors</h1>
    <p>We have many projects that are meant to support the smooth running of our business.</p>

    <div class="row">
        
        

      
        <div class="facilities-col">
            <img src="p4.jpg">
            <h3> NAHWERA PRAISE</h3>
            <p>We are so glad for her great support as one of the Business Director.</p>
        </div>

        <div class="facilities-col">
            <img src="derah.jpg">
            <h3>NATUMANYA ADERAH</h3>
            <p>We are so glad for her great support as one of the Business Director.</p>
        </div>
        <div class="facilities-col">
            <img src="a.jpg">
            <h3>OWOYESIGA ASHRAF</h3>
            <p>We are so glad for his great support as one of the Business Director.</p>
        </div>
     
       
    </div>
</section>


<section class="facilities">
    <h1> Our Branch Staff</h1>
    <p>We have a well qualified and disciplined staff in all our branches across the country.</p>

    <div class="row">
        

        <div class="facilities-col">
            <img src="ff.jpg">
            <h3>Staff KABALE Branch</h3>
            <p>We are so glad for their great support as one of the business. </p>
        </div>

        <div class="facilities-col">
            <img src="b1.jpg">
            <h3>Staff NTUNGAMO Branch </h3>
            <p>We are so glad for their great support as one of the business.</p>
        </div>


        <div class="facilities-col">
            <img src="f.jpg">
            <h3>Staff MBARARA Branch</h3>
            <p>We are so glad for their great support as one of the business.</p>
        </div>
       
    </div>
</section>

<section>
<div class="facilities">
    
    <h1>Our Employee Payrol System</h1>

    <p>This is the system that govern the payments of our employees. <br> You can click in the link below to access it.</p>
    <a href="login.php" class="hero-btn">Our Payrol System</a>
   
</div>


</section>


<section class="footer">
<p>Real Time Kitchen ware endeavors to provide discerning hospitality to guests by offering quality service<br>and experiences in some of the most exotic destinations in Africa and beyond.</p>

<div>
    <ul class="icons">
    <i><a href="https://facebook.com/Praise Nahwera" class="icon fa fa-facebook"><span class="label"> facebook</span></a></i>
    <i><a href="https://whatsapp.com/0782391493" class=" icon fa fa-whatsapp"><span class="label"> whatsapp</span></a></i>
    <i><a href="mailto:nahwerapraise37@gmail.com" class="icon fa fa-envelope"><span class="label"> Email</span></a></i>
</ul>

</div>
</section>
    

    <script>
    var navLinks = document.getElementById("navLinks");
    
    function showMenu(){
        navLinks.style.right = "0";
    } 
    function hideMenu() {
        navLinks.style.right = "-200px";
    } 
    </script>
    
</body>
</html>