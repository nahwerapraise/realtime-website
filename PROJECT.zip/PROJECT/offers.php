<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>praise</title>
    <link rel="stylesheet" href="offerz.css">
 
    <link rel="preconnect" href="https://fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css2?
    family=poppins:wght@100;200;300;400;600;700&display=swap"
    rel="stylesheet">
   
     <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 

<body>
    
    <section class="header">
        <nav>
   <a href="spo.html"> <img src="dishes.jpg"></a>

    
    <div class="nav-links" id="navLinks">
        <i class="fa fa-times" onclick="hideMenu()"></i>

    <ul>
        <li><a href="Home.php"> HOME</a></li>
        <li><a href="About.php"> ABOUT</a></li>
        <li><a href="offers.php"> OFFERS</a></li>
      <li><a href="staff.php"> STAFF</a></li>
        <li><a href="contact.php"> CONTACT</a></li>
    </ul>
    </div>
    <i class="fa fa-bars" onclick="showMenu()"></i>
  
    </nav>
    
    <div class="text-box">
    
        <h1>OUR OFFERS</h1>
    
        <p></p>
        <a href="contact.php" class="hero-btn">Visit Us To Know More</a>
    
    </div>
    
    </section>


<section class="facilities">
    <h1>Some Of Our Offers</h1>
    <p>Our business is ranked as the best in  providing  many offers as some are as indicated below</p>

    <div class="row">
    

    <div class="facilities-col">
            <img src="greater.jpg">
            <h3>The Classic greaters</h3>
            <p>We have the best greaters in all of our Branches across the country.</p>
            <a href="Book.php" class="hero-btn">BOOK WITH US</a>
        </div>

    <div class="facilities-col">
            <img src="d.jpg">
            <h3>Best flyingpans</h3>
            <p>We have the best flyingpans in all of our Branches across the country.</p>
            <a href="Book.php" class="hero-btn">BOOK WITH US</a>
        </div>
    

        <div class="facilities-col">
            <img src="wood.jpg">
            <h3>The Greatest wooden cutlery</h3>
            <p>We have the greatest cutlery in all of our Branches across the country.</p>
            <a href="Book.php" class="hero-btn">BOOK WITH US</a>
        </div>
       
    </div>
</section>

<section class="testimonials">
    <h1>What Our Customers Say</h1>
    <p>We glad to say that your shop offers  good quality products  <br> We therefore rating your shop as the best providers of good quality products.</p>

    <div class="row">

    
        <div class="testimonials-col">
            <img src="praise.jpg">
<div>
<p>I'm glad to say that your shop offers the many good quality products  <br> I'm therefore rating your shop as the best providers of good quality and affordable products.</p>
    <h3 id="std">Praise</h3>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star-half-o"></i>
</div>

</div>

<div class="testimonials-col">
            <img src="derah.jpg">
       <div>
       <p>I'm glad to say that your shop has the best delivery serivces  <br> I'm therefore rating your shop as the best with better delivery services.</p>
    <h3 id="std">Aderah</h3>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star-o"></i>
</div>

</div>

</div>
</section>



<section class="footer">
<h4>About Us</h4>
<p>Real Time Kitchen Ware endeavors to provide discerning products at affordable prices<br>and best delivery services in Africa and beyond.</p>

<div class="icons">
    <i class="fa fa-facebook"></i>
    <i class="fa fa-twitter"></i>
    <i class="fa fa-instagram"></i>
    <i class="fa fa-whatsapp"></i>
    <i class="fa fa-linkedin"></i>

</div>

</section>
    
    
    <script>
    var navLinks = document.getElementById("navLinks");
    
    function showMenu(){
        navLinks.style.right = "0";
    } 
    function hideMenu() {
        navLinks.style.right = "-200px";
    } 
    </script>
    
</body>
</html>