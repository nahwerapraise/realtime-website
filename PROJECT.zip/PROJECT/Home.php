
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Praise</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 


<style>
    #avbar{
    margin-bottom: 0;
    border-radius: 0;
    background-color: ;
    color: #fff;
   padding: 2%;
    font-size: 1.2em;
    border: 0;
}
    .navbar{
    margin-bottom: 0;
    border-radius: 0;
    background-color: ;
    color: #fff;
    padding: 1% 0;
    font-size: 1.2em;
    border: 0;
}

.navbar-brand{
    float: left;
    min-height: 55px;
    padding: 0 15px 5px;
}
.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus, .navbar-inverse .navbar-nav .active a:hover{
    color: #fff;
    background-color: ;
     
}
.navbar-inverse .navbar-nav li a{
    color: #d5d5d5;
}
#im{
    border-radius: 50%;
    height:70px ;
    width: 80px;
}


nav{
    display: flex;
    padding: 2% 6%;
    justify-content: space-between;
    align-items: center;
    background-color: green;
    }
     .nav-links{
        flex: 1;
        text-align: right;
    }
    .nav-links ul li{
        list-style: none;
        display: inline-block;
        padding: 8px 12px;
        position: relative;
    }
    .nav-links ul li a{
        Color: #fff;
        text-decoration: none;
        font-size: 13px;
    }
    
.nav-links ul li::after{
    content: '';
    width: 0%;
    height: 2px;
    background: #f44336;
    display: block;
    margin: auto;
    transition: 0.5s;
}
.nav-links ul li:hover::after{
    width: 100%
}
.text-box{
    width: 90%;
    color: #fff;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    text-align: center;
}
.text-box h1{
    font-size: 62px;
}
.text-box p{
    margin: 10px 0 40px;
    font-size: 14px;
    color: #fff;
}
.hero-btn{
    display: inline-block;
    text-decoration: none;
    color: #fff;
    border: 1px solid black;
    padding: 12px 34px;
    font-size: 13px;
    background: orange;
    position: relative;
    cursor: pointer;
}
.hero-btn:hover{
    border: 1px solid #f44336;
    background:#f44336;
    transition: 1s;
}
nav .fa{
    display: none;
}
.navbar-inverse .navbar-nav li a{
    color: #d5d5d5;
}
.carousel-caption{
    top: 50%;
    transform: translateY(-50%);
    text-transform: uppercase;
}
.btn{
    font-size: 18px;
    color: #fff;
    padding: 12px 22px;
    background-color: #5e4485;
    border: 2px solid#fff;
}

.glyphicon{
    color: #fff;
    background-color:black;
    border-radius: 50%;
    padding-bottom:35px;
    padding-top:5px;
    padding-right:30px;
    padding-left:2px;
}

     
.course{
    width: 80%;
    margin: auto;
    text-align: center;
    padding-top: 100px;
}
    h1{
        font-size: 36px;
        font-weight: 600;
    }
    p{
        color: #777;
        font-size: 14px;
        font-weight: 300;
        line-height:22px;
        padding: 10px;
    }
    .row{
        margin-top: 5%;
        display: flex;
        justify-content: space-between;
    }
    .course-col{
        flex-basis: 31%;
        /* background: #fff3f3; */
        background: lightpink;
        border-radius: 10px;
        margin-bottom: 5%;
        padding: 20px 12px;
        box-sizing: border-box;
        transition: 0.5s;
    }
    h3{
        text-align: center;
        font-weight: 600;
        margin: 10px 0;
    }
    .course-col:hover{
        box-shadow: 0 0 20px 0px rgba(0,0,0,0.2);

    }


.campus{
        width: 80%;
        margin: auto;
        text-align: center;
        padding-top: 50px;
    }
    .campus-col{
        flex-basis: 32%;
        border-radius: 10px;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;

    }
    .campus-col img{
        width: 100%;
        display: block;
        
    }
    .layer{
    background: transparent;
    height: 100%;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
   
    }
    
    .layer h3{
        width: 100%;
        font-weight: 500;
        color: #fff;
        font-size: 26px;
        bottom: 0;
        left: 50%;
    
        position: absolute;
       
    }
    


.facilities{
    width: 80%;
    margin: auto;
    text-align: center;
    padding-top: 100px;
}
.facilities-col{
    flex-basis: 31%;
    border-radius: 10px;
    margin-bottom: 5%;
    text-align:left;
}
.facilities-col img{
    width: 100%;
    border-radius: 10px;
}
.facilities-col P{
    padding: 0;
}
.facilities-col h3{
    margin-top: 16px;
    margin-top: 15px;
    text-align: left;
}




.testimonials{
    width: 80%;
    margin: auto;
    padding-top: 100px;
    text-align: center;
}
.testimonials-col{
    flex-basis: 44%;
    border-radius: 10px;
    margin-bottom: 15px;
    text-align: left;
    /* background: #fff3f3; */
    background: lightpink;
    padding: 25px;
    cursor: pointer;
    display: flex;
}
.testimonials-col img{
    height: 40px;
    margin-left: 5px;
    margin-right: 30px;
    border-radius: 50%;
}
.testimonials-col p{
    padding: 0;
}
.testimonials-col h3{
    margin-top: 15px;
    text-align: left;
}
.testimonials-col .fa{
    color: #f44336;

}


#icon{
max-width: 200px;
margin: 1% auto;
}
footer{
    width: 100%;
    background-color: green;
    padding: 1%;
    color: #fff;
}
#cnt{
    padding: 15px;
    font-size: 25px;
    color: #fff;
}
#cnt:hover{
    color: orange;
text-decoration: none;
}
#hid{
    color:blue;
    margin-left: 350px;
    font-size: 25px;
  ;
}
.glyphicon{
    color: #fff;
    background-color:black;
    border-radius: 50%;
    padding-bottom:35px;
    padding-top:5px;
    padding-right:30px;
    padding-left:2px;
}


#infn p{
    color:#fff;
    background-color: black;
    text-align: center;
    
}
video{
    padding-left:300px;
    height: 400px;
}

@media(max-width:900px){
   

.glyphicon{
    color: #fff;
    background-color:black;
    border-radius: 50%;
    padding-bottom:10px;
    padding-top:5px;
    padding-right:7px;
    padding-left:2px;
}
    .text-box h1{
        font-size: 20px;
    }
    .nav-links ul li{
        display: block;
    
    }
    .nav-links{
        position: absolute;
        background: #f44336;
        height: 100vh;
        width: 200px;
        top: 0;
        right:-200px;
        text-align: left;
        z-index: 2;
        transition: 1s;
    }
    #im{
    border-radius: 50%;
    height:40px ;
    width: 50px;
}

    
    
    nav .fa{
        display: block;
        color: #fff;
        margin: 10px;
        font-size: 22px;
        cursor: pointer;
       
    }
    
.nav-links ul{
    padding: 30px;
}

.carousel-caption{
    display: none;
}

.row{
    flex-direction: column;
}

video{
    padding-left:70px;
    height: 200px;
}


.container{
    margin: 4% auto;
}
#hid{
;
    margin-left: 100px; 
    
}

h1{
        font-size: 25px;
        font-weight: 600;
    } 
    h3{
        font-size:20px;
        font-weight: 600;
    }

#cnt{
    padding: 10px;
    font-size: 15px;
    color: #fff;
}


#std{
    font-size: 15px;
}



#hid{
    color:blue;
    margin-left: 100px;
    font-size: 15px;
  ;
}

    }

    
.wor{
    color: white;
    
}
#hdi{
text-align:center;

}

</style>
</head>
<body>
    <nav class="navbar navbar-inverse" id="avbar">
<div class="container-fluid">
<div class="navbar-header">
</div>
</nav>

<section class="header">
    <nav>
<a href="log.png"> <img src="log.png" id="log.png"></a>

<div class="nav-links" id="navLinks">
    <i class="fa fa-times" onclick="hideMenu()"></i>

    <ul>
        <li><a href="Home.php"> HOME</a></li>
        <li><a href="About.php"> ABOUT</a></li>
        <li><a href="offers.php"> OFFERS</a></li>
      <li><a href="staff.php"> STAFF</a></li>
        <li><a href="contact.php"> CONTACT</a></li>
    </ul>
</div>
<i class="fa fa-bars" onclick="showMenu()"></i>

</nav>

</section>
     
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
    <li data-target="#myCarousel" data-slide-to="4"></li>
    <li data-target="#myCarousel" data-slide-to="5"></li>
    <li data-target="#myCarousel" data-slide-to="6"></li>
    <li data-target="#myCarousel" data-slide-to="7"></li>
    
    </ol>
    
    <div class="carousel-inner" role="listbox">
    <div class="item active">
    <img src="cups and plates.jpg">
    <div class="carousel-caption">
        <h1 class="wor",color="red" >REAL TIME KITCHEN WARE</h1>
        <br>
        <h3>QUALITY PRODUCTS</h3>
        <br>
        <button type="button" class="btn btn-default">Welcome</button>
    </div>
    </div>
   

    <div class="item">
    <img src="dishes.jpg">
    </div>

    <div class="item">
    <img src="cups $ plates.jpg">
    </div>

    <div class="item">
    <img src="cups and plates.jpg">
    </div>

    <div class="item">
    <img src="saucepans.jpg" >
    </div>

    <div class="item">
    <img src="shop.jpg">
    </div>

    <div class="item">
    <img src="spo.jpg">
    </div>

    <div class="item">
    <img src="greater.jpg">
    </div>
    
    
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
        </a>
    
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
        </a>
    </div>
    </div>
   

<section class="facilities">
    <h1>Our Basic products.</h1>
    <p>We sell all different kinds of dishes at their respective sizes and prices.</p>
    <div class="row">
        
        

        <div class="facilities-col">
            <img src="saucepans.jpg">
            <h3>SAUCEPANS.</h3>
            <p>We offer the best saucepans</p>
            <a href="Order.php" class="hero-btn">PLACE ORDER</a>
        </div>

        <div class="facilities-col">
            <img src="cups $ plates.jpg">
            <h3>CUPS AND PLATES.</h3>
            <p>We offer the cups and plates</p>
            <a href="Order.php" class="hero-btn">PLACE ORDER</a>
        </div>


        <div class="facilities-col">
            <img src="cut.jpg">
            <h3>CUTLERY.</h3>
            <p>We offer the best  cutlery</p>
            <a href="Order.php" class="hero-btn">PLACE ORDER</a>
        </div>
       
    </div>
</section>


<section class="campus">
    <h1>Our Branches</h1>
    <p>We have different braches across the country.</p> 

    <div class="row">

<div class="campus-col">
<img src="s5.jpg">
<div class="layer">
    <h3> KABALE BRANCH</h3>
</div>
</div>


<div class="campus-col">
    <img src="s3.jpg">
    <div class="layer">
        <h3> NTUNGAMO BRANCH</h3>
    </div>
    </div>


<div class="campus-col">
<img src="s2.jpg">
<div class="layer">
    <h3> MBARARA BRANCH</h3>
</div>
</div>

</div>
</section>


<section class="facilities">
    <h1>Our main KABALE Branch</h1>
    <p>Our main branch is Located along Kabale-Kisoro road in Kabale Municipality</p>

    <div class="row">
        
        

        <div class="facilities-col">
            <img src="plates.jpg">
            <h3>The Classic plates</h3>
            <p>We have the best plates in all our Branches across the country.</p>
            <a href="Book.php" class="hero-btn">BOOK WITH US</a>
        </div>

        <div class="facilities-col">
            <img src="dd.jpg">
            <h3>Best dishes</h3>
            <p>We have the best dishes in all our Branches across the country.</p>
            <a href="Book.php" class="hero-btn">BOOK WITH US</a>
        </div>


        <div class="facilities-col">
            <img src="c.jpg">
            <h3>The best cutlery</h3>
            <p>We have the best cutlery in all our Branches across the country.</p>
            <a href="Book.php" class="hero-btn">BOOK WITH US</a>
        </div>
       
    </div>
</section>

<section class="testimonials">
    <h1>What Our Customers Say.</h1>
    <p>We are glad to say that your shop has best kitchen ware materials <br> We therefore rating your shop as the best providers of good quality products.</p>

    <div class="row">

        <div class="testimonials-col">
            <img src="praise.jpg">
       <div>
       <p>I'm glad to say that your has best kitchen ware materials   <br> I'm therefore rating your shopas the best providers of good quality products.</p>
    <h3 id="std">PRAISE SHAZ</h3>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star-o"></i>
</div>

</div>

        <div class="testimonials-col">
            <img src="derah.jpg">
<div>
<p>I'm glad to say that your shop offers the best products at affordable prices  <br> I'm therefore rating your shop as the best providers of good affordable products.</p>
    <h3 id="std">ADERAH</h3>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star-half-o"></i>
</div>

</div>

</div>
</section>


<br> <br> <br> <br>


<footer class="container-fluid text-center">
    <div class="row">
<div class="col-sm-4">
<h3>Get In Touch</h3>   
<br>
<h4>Our Address and contact info here</h4> 
</div>

<div class="col-sm-4">
    <h3>Connect </h3>
    <a href="https://facebook.com" class="fa fa-facebook" id="cnt"></a>  
    <a href="https://web.whatsapp.com/0782391493" class="fa fa-whatsapp" id="cnt"></a>
    <a href="https://www.youtube.com" class="fa fa-youtube" id="cnt"></a>
    <p class="copyright">&copy; Untitled. Design: <a href "https://templated.co">TEMPLATED</a>.images:<a href="https://a.jpg"></a>    

</div>

    <div class="col-sm-4">
    <img src="log.png" class="icon">  
 </div>
</div>
</footer>

    <script>
        var navLinks = document.getElementById("navLinks");
        
        function showMenu(){
            navLinks.style.right = "0";
        } 
        function hideMenu() {
            navLinks.style.right = "-200px";
        } 
        </script>
        




</body>
</html>