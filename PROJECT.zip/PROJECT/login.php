
    <!DOCTYPE html>    
    <html>    
    <head>    
        <title>REAL TIME KITCHEN WARE</title>    
        <link rel="stylesheet" href="logg.css">  
    </head>    
    <body>    
        <h2>REAL TIME KITCHEN WARE </h2><br>
     
        <h3 id="exam"> LOG IN SYSTEM</h3>    
        <h3> LOG IN HERE</h3>    
        <div class="login">    
        <form id="login" method="get" action="nyamitanga.php">    
            <label><b>    
            </b>    
            </label>    
            <input type="text" name="Uname" id="Uname" placeholder="Enter your Username">    
            <br><br>    
            <label><b> 
            </b>    
            </label>    
            <input type="Password" name="Pass" id="Pass" placeholder="Enter your Password">    
            <br><br>    
            <input type="Password" name="Pass" id="Pass" placeholder="Confirm your Password">    
            <br><br>    
          
            <a href="log in.php"> <input type="button" name="log" id="log" value="LOG IN" >   </a>
               
               
        </form>     
    </div>    
    </body>    
    </html>     
